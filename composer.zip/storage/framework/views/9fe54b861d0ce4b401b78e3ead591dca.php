<?php $__env->startSection('isihalaman'); ?>
    <div class="container py-4">
        <h2>Data Hinterland Daerah: <?php echo e(ucfirst($user->region)); ?></h2>

        
        <a href="#" class="btn btn-success mb-3" data-bs-toggle="modal" data-bs-target="#modalTambahTab">
            Tambah Data Tab Hinterland
        </a>

        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Tab</th>
                    <th>Konten</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $tabs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <?php switch($tab->tab_name):
                                case ('analisa_data'): ?>
                                    Analisa Data
                                <?php break; ?>

                                <?php case ('kukm_perindustrian'): ?>
                                    Data KUKM dan Perindustrian
                                <?php break; ?>

                                <?php case ('perdagangan'): ?>
                                    Data Perdagangan
                                <?php break; ?>

                                <?php case ('pariwisata'): ?>
                                    Data Pariwisata
                                <?php break; ?>

                                <?php case ('perikanan_kelautan'): ?>
                                    Data Perikanan dan Kelautan
                                <?php break; ?>

                                

                                <?php default: ?>
                                    <?php echo e(ucfirst($tab->tab_name)); ?>

                            <?php endswitch; ?>
                        </td>
                        <td><?php echo Str::limit(strip_tags($tab->content), 100); ?></td>
                        <td>
                            <a href="<?php echo e(route('hinterland-tabs.edit', $tab->id)); ?>" class="btn btn-sm btn-warning">Edit</a>
                            <form action="<?php echo e(route('hinterland-tabs.destroy', $tab->id)); ?>" method="POST"
                                style="display:inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-sm btn-danger"
                                    onclick="return confirm('Yakin hapus?')">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    
    <style>
        /* Membesarkan modal */
        .modal-dialog {
            max-width: 900px;
        }
    </style>
    <div class="modal fade" id="modalTambahTab" tabindex="-1" aria-labelledby="modalTambahTabLabel" aria-hidden="true">
        <div class="modal-dialog">
            <form method="POST" action="<?php echo e(route('hinterland-tabs.store')); ?>">
                <?php echo csrf_field(); ?>
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="modalTambahTabLabel">Tambah Data Tab Hinterland</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        
                        <div class="mb-3">
                            <label class="form-label">Tab</label>
                            <select name="tab_name" class="form-control" required>
                                <option value="analisa_data">Analisa Data</option>
                                <option value="kukm_perindustrian">Data KUKM dan Perindustrian</option>
                                <option value="perdagangan">Data Perdagangan</option>
                                <option value="pariwisata">Data Pariwisata</option>
                                <option value="perikanan_kelautan">Data Perikanan dan Kelautan</option>
                                <option value="galeri">Galeri</option>
                                <option value="maps">Maps</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Konten</label>
                            <input id="tab-content" type="hidden" name="content">
                            <trix-editor input="tab-content"></trix-editor>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-primary">Simpan</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\simpul-laut\resources\views/home.blade.php ENDPATH**/ ?>