
<?php $__env->startSection('isihalaman'); ?>
    <div class="container py-4">
        <h4>Edit Data Tab Hinterland</h4>
        <form method="POST" action="<?php echo e(route('hinterland-tab.update', $tab->id)); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <input type="hidden" name="region" value="<?php echo e($tab->region); ?>">
            <input type="hidden" name="tab_name" value="<?php echo e($tab->tab_name); ?>">
            <div class="mb-3">
                <label class="form-label">Konten</label>
                <input id="x" type="hidden" name="content" value="<?php echo e($tab->content); ?>">
                <trix-editor input="x"></trix-editor>
            </div>
            <button type="submit" class="btn btn-primary">Update</button>
        </form>
    </div>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="https://unpkg.com/trix@2.0.0/dist/trix.css">
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
    <script src="https://unpkg.com/trix@2.0.0/dist/trix.js"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\simpul-laut\resources\views/data-hinterland/edit-tab.blade.php ENDPATH**/ ?>